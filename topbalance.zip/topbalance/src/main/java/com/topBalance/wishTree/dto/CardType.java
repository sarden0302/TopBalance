package com.topBalance.wishTree.dto;

public enum CardType {
    SPADE, CLOVER, HEART, DIAMOND;
}
