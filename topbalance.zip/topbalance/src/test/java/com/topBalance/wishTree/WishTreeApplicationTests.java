package com.topBalance.wishTree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WishTreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
